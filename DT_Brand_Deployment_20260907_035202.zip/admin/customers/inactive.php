<?php
/* DT admin access guard (auto-inserted) */ $__dtg = $_SERVER['DOCUMENT_ROOT'] . '/admin/includes/adminguard.php'; if (is_file($__dtg)) require_once $__dtg;

/**
 * inactive.php — Inactive & Dormant Customer Accounts Hub
 * DT Brand's & Jai Hanuman Tex — Luxury Master Design System
 */
require_once __DIR__ . '/../../src/CustomerManager.php';

use DTBrand\CustomerManager;

// customers.status has no 'inactive' value -- the ENUM is active|pending|suspended
// -- so "dormant" here means suspended.
$customersList = CustomerManager::getAll();
$suspendedCount = 0;
foreach ($customersList as $c) {
    if (($c['status'] ?? '') === 'suspended') $suspendedCount++;
}

$page_title = "Inactive & Dormant Customers";
$active_nav = "customers";
$active_subnav = "inactive";
$active_filter = "inactive";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> — DT Brand's Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/admin/assets/css/admin.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="/admin/customers/assets/css/customers.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="/admin/customers/assets/css/customer-list.css?v=<?php echo time(); ?>">
</head>
<body>
<div class="adm-layout">
    <?php include_once __DIR__ . '/../includes/adminsidebar.php'; ?>
    <div class="adm-main">
        <?php include_once __DIR__ . '/../includes/adminheader.php'; ?>
        <main class="adm-content" style="padding: 14px 18px; width: 100%; max-width: 100%; box-sizing: border-box;">
            
            <div class="dt-customers-container">
                <div class="dt-cust-head">
                    <div class="dt-cust-title-group">
                        <h1 class="dt-cust-title">
                            <span>Inactive &amp; Dormant Customers</span>
                            <span class="dt-cust-badge" style="background:#FEF3C7; color:#B45309; border:1px solid #FCD34D;"><?php echo number_format($suspendedCount); ?> Suspended</span>
                        </h1>
                        <p class="dt-cust-subtitle">Shoppers with no purchases in the last 60+ days or accounts pending re-engagement campaigns.</p>
                    </div>
                    <div class="dt-cust-actions">
                        <a href="/admin/customers/index.php" class="dt-btn dt-btn-pale"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="margin-right:4px;"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>All Customers</a>
                        <a href="/admin/customers/export.php" class="dt-btn dt-btn-gold">Export Dormant List</a>
                    </div>
                </div>

                <?php include __DIR__ . '/components/customer-stats.php'; ?>
                <?php include __DIR__ . '/components/customer-search.php'; ?>
                <?php include __DIR__ . '/components/customer-table.php'; ?>
            </div>

            <?php include __DIR__ . '/components/customer-filters.php'; ?>
            <?php include __DIR__ . '/components/customer-status.php'; ?>
            <?php include __DIR__ . '/components/bulk-actions.php'; ?>

        </main>
        <?php include_once __DIR__ . '/../includes/adminfooter.php'; ?>
    </div>
</div>

<script>
    window.dbCustomersData = <?= json_encode($customersList) ?>;
</script>
<script src="/admin/customers/assets/js/customers.js?v=<?php echo time(); ?>"></script>
<script src="/admin/customers/assets/js/customer-list.js?v=<?php echo time(); ?>"></script>
<script src="/admin/customers/assets/js/customer-filters.js?v=<?php echo time(); ?>"></script>
<script src="/admin/customers/assets/js/customer-status.js?v=<?php echo time(); ?>"></script>
<script src="/admin/customers/assets/js/bulk-actions.js?v=<?php echo time(); ?>"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    if (typeof filterCustomersByStatus === 'function') {
        filterCustomersByStatus('inactive');
    }
});
</script>
</body>
</html>
