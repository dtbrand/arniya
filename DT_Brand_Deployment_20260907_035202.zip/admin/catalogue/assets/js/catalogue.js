/**
 * catalogue.js — Master JavaScript Controller for DT Brand's Catalogue Module
 * DT Brand's & Jai Hanuman Tex
 */

window.DT_CATALOGUE = {
    // Show Toast notification using Admin Toast or fallback
    showToast: function(msg, _type = 'gold') {
        if (typeof window.showToast === 'function') {
            window.showToast(msg);
            return;
        }
        let container = document.getElementById('dtToastContainer');
        if (!container) {
            container = document.createElement('div');
            container.id = 'dtToastContainer';
            container.style.cssText = 'position:fixed; bottom:20px; right:20px; z-index:999999; display:flex; flex-direction:column; gap:8px;';
            document.body.appendChild(container);
        }
        const toast = document.createElement('div');
        toast.style.cssText = 'background:#181512; color:#fff; border:1px solid #D4AF37; border-radius:6px; padding:10px 16px; font-size:12px; font-weight:700; box-shadow:0 4px 14px rgba(0,0,0,0.25); display:flex; align-items:center; gap:8px; animation:fadeIn 0.2s ease;';
        toast.innerHTML = `<svg viewBox="0 0 24 24" width="14" height="14" fill="#D4AF37"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg> <span>${msg}</span>`;
        container.appendChild(toast);
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transition = 'opacity 0.3s ease';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    },

    // Real-time table filter with 1-tap clear button
    filterTable: function(inputId, tableId, clearBtnId) {
        const input = document.getElementById(inputId);
        const table = document.getElementById(tableId);
        const clearBtn = clearBtnId ? document.getElementById(clearBtnId) : null;
        if (!input || !table) return;

        const val = input.value.toLowerCase().trim();
        if (clearBtn) {
            clearBtn.style.display = val.length > 0 ? 'inline' : 'none';
        }

        const rows = table.querySelectorAll('tbody tr');
        rows.forEach(r => {
            const txt = r.textContent.toLowerCase();
            if (txt.includes(val)) {
                r.style.display = '';
            } else {
                r.style.display = 'none';
            }
        });
    },

    // Clear search
    clearSearch: function(inputId, tableId, clearBtnId) {
        const input = document.getElementById(inputId);
        if (input) {
            input.value = '';
            this.filterTable(inputId, tableId, clearBtnId);
            input.focus();
        }
    },

    // Master Select All Checkboxes
    toggleSelectAll: function(master, childClass = 'dt-row-check') {
        const checks = document.querySelectorAll('.' + childClass);
        checks.forEach(c => c.checked = master.checked);
    },

    // Apply Bulk Actions
    applyBulkAction: function(selectId, checkClass) {
        const select = document.getElementById(selectId);
        if (!select || !select.value) {
            this.showToast('Please select a bulk action from the dropdown.');
            return;
        }
        const action = select.value;
        const checkedBoxes = Array.from(document.querySelectorAll('.' + checkClass + ':checked'));
        if (checkedBoxes.length === 0) {
            this.showToast('Please select at least one item first.');
            return;
        }

        const count = checkedBoxes.length;
        if (action === 'activate') {
            checkedBoxes.forEach(chk => {
                const row = chk.closest('tr');
                if (row) {
                    row.setAttribute('data-status', 'active');
                    const badge = row.querySelector('.dt-badge.red, .dt-badge.gray');
                    if (badge) {
                        badge.className = 'dt-badge green';
                        badge.textContent = 'Active';
                    }
                }
            });
            this.showToast(`Activated ${count} selected categories!`);
        } else if (action === 'deactivate') {
            checkedBoxes.forEach(chk => {
                const row = chk.closest('tr');
                if (row) {
                    row.setAttribute('data-status', 'inactive');
                    const badge = row.querySelector('.dt-badge.green');
                    if (badge) {
                        badge.className = 'dt-badge gray';
                        badge.textContent = 'Inactive';
                    }
                }
            });
            this.showToast(`Deactivated ${count} selected categories!`);
        } else if (action === 'feature') {
            checkedBoxes.forEach(chk => {
                const row = chk.closest('tr');
                if (row) {
                    const starBtn = row.querySelector('.wp-star-btn');
                    if (starBtn) {
                        starBtn.classList.add('active');
                        starBtn.style.color = '#D4AF37';
                    }
                }
            });
            this.showToast(`Marked ${count} categories as Featured!`);
        } else if (action === 'delete') {
            if (!confirm(`Are you sure you want to delete ${count} selected categories?`)) return;
            checkedBoxes.forEach(chk => {
                const row = chk.closest('tr');
                if (row) {
                    row.style.transition = 'all 0.25s ease';
                    row.style.opacity = '0';
                    row.style.transform = 'translateX(20px)';
                    setTimeout(() => row.remove(), 250);
                }
            });
            this.showToast(`Deleted ${count} selected categories!`);
        }
    },

    // Delete row with smooth animation
    deleteRow: function(rowId, itemName) {
        if (!confirm(`Are you sure you want to delete "${itemName}"?`)) return;
        const row = document.getElementById(rowId);
        if (!row) return;

        row.style.transition = 'all 0.25s ease';
        row.style.opacity = '0';
        row.style.transform = 'translateX(20px)';
        setTimeout(() => {
            row.remove();
            this.showToast(`"${itemName}" deleted successfully!`);
        }, 250);
    },

    // Image preview helper for file inputs
    previewImage: function(input, targetImgId) {
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const img = document.getElementById(targetImgId);
                if (img) {
                    img.src = e.target.result;
                    img.style.display = 'block';
                }
            };
            reader.readAsDataURL(input.files[0]);
        }
    },

    // Auto Slug Generator
    generateSlug: function(sourceInputId, targetSlugId) {
        const src = document.getElementById(sourceInputId);
        const tgt = document.getElementById(targetSlugId);
        if (src && tgt) {
            tgt.value = src.value.toLowerCase()
                .replace(/[^a-z0-9\s-]/g, '')
                .trim()
                .replace(/\s+/g, '-');
        }
    },

    // ════ AI SEO Auto-Generator ════
    generateAiSeo: function(catName, catSlug) {
        const titleInput = document.getElementById('seoTitleInput');
        const descInput = document.getElementById('seoDescInput');
        const titleDisplay = document.getElementById('serpTitleDisplay');
        const descDisplay = document.getElementById('serpDescDisplay');
        const titleCount = document.getElementById('seoTitleCount');
        const descCount = document.getElementById('seoDescCount');

        const cleanName = catName || 'Silk Sarees & Handlooms';
        const cleanSlug = catSlug || cleanName.toLowerCase().replace(/[^a-z0-9]+/g, '-');

        const aiTitles = [
            `Pure ${cleanName} Wholesale | Direct Surat Factory Rates`,
            `Buy Authentic ${cleanName} Wholesale Catalogues | DT Brand's`,
            `Surat ${cleanName} Central Depot Wholesale Ready Stock Lots`
        ];

        const aiDescriptions = [
            `Buy authentic pure ${cleanName.toLowerCase()} at direct Surat factory wholesale rates. Certified handloom and luxury weaves with fast 24h ready depot dispatch across India.`,
            `Explore Surat's finest ${cleanName.toLowerCase()} collection. Exclusive wholesale lot deals, GST invoicing, verified Silk Mark quality, and instant WhatsApp support.`,
            `Premium ${cleanName.toLowerCase()} wholesale assortment from Surat central depot. Best reseller profit margins, low MOQ lot bundles, and express doorstep delivery.`
        ];

        const selectedTitle = aiTitles[Math.floor(Math.random() * aiTitles.length)];
        const selectedDesc = aiDescriptions[Math.floor(Math.random() * aiDescriptions.length)];

        const slugDisplay = document.getElementById('serpSlugDisplay');
        if (slugDisplay) slugDisplay.textContent = cleanSlug;

        if (titleInput) {
            titleInput.value = selectedTitle;
            if (titleDisplay) titleDisplay.textContent = selectedTitle;
            if (titleCount) titleCount.textContent = selectedTitle.length + ' / 60';
        }

        if (descInput) {
            descInput.value = selectedDesc;
            if (descDisplay) descDisplay.textContent = selectedDesc;
            if (descCount) descCount.textContent = selectedDesc.length + ' / 160';
        }

        this.showToast(`AI SEO Meta Generated for "${cleanName}"!`);
    },

    // ════ AI Category Description Auto-Generator ════
    generateAiCategoryDesc: function(targetTextareaId, catName) {
        const textarea = document.getElementById(targetTextareaId);
        if (!textarea) return;

        const cleanName = catName || 'Silk Sarees & Handlooms';
        const aiDescs = [
            `Surat central depot master collection of pure ${cleanName.toLowerCase()}. Sourced directly from registered master weavers with certified zari purity, authentic border weaving, and 24-hour priority dispatch for wholesale buyers and boutiques.`,
            `Handcrafted and premium powerloom ${cleanName.toLowerCase()} manufactured in Surat textile hub. High colorfastness, rich pallu motifs, standard wholesale bundle packaging, and verified reseller price margins.`,
            `Exclusive festive and bridal ${cleanName.toLowerCase()} assortment featuring heavy zari embroidery, soft drape fabrics, and Silk Mark certified handloom lots tailored for top retail boutiques.`
        ];

        const selected = aiDescs[Math.floor(Math.random() * aiDescs.length)];
        textarea.value = selected;
        this.showToast(`AI Generated Description for "${cleanName}"!`);
    },

    // ════ Interactive Device Preview Switcher (Desktop vs Mobile) ════
    switchDevicePreview: function(device) {
        const btnDesk = document.getElementById('btnPrevDesk');
        const btnMob = document.getElementById('btnPrevMob');
        const boxDesk = document.getElementById('prevBoxDesk');
        const boxMob = document.getElementById('prevBoxMob');

        if (device === 'mob') {
            if (btnDesk) btnDesk.classList.remove('active');
            if (btnMob) btnMob.classList.add('active');
            if (boxDesk) boxDesk.style.display = 'none';
            if (boxMob) boxMob.style.display = 'block';
        } else {
            if (btnMob) btnMob.classList.remove('active');
            if (btnDesk) btnDesk.classList.add('active');
            if (boxMob) boxMob.style.display = 'none';
            if (boxDesk) boxDesk.style.display = 'block';
        }
    },

    // ════ Banner Ratio Change Handler ════
    updateBannerRatio: function(type, ratio) {
        if (type === 'desk') {
            const deskImg = document.getElementById('deskBannerPreview');
            const liveDeskImg = document.getElementById('liveDeskImg');
            if (deskImg) {
                if (ratio === '1-1') deskImg.style.height = '180px';
                else if (ratio === '4-1') deskImg.style.height = '70px';
                else deskImg.style.height = '90px';
            }
            if (liveDeskImg) {
                if (ratio === '1-1') liveDeskImg.style.height = '180px';
                else if (ratio === '4-1') liveDeskImg.style.height = '70px';
                else liveDeskImg.style.height = '90px';
            }
            this.showToast(`Desktop banner aspect ratio set to ${ratio}!`);
        } else {
            const mobImg = document.getElementById('mobileBannerPreview');
            const slot = document.getElementById('mobBannerSlot');
            const sizeTag = document.getElementById('mobileSizeTag');

            if (ratio === '1080-520') {
                if (mobImg) { mobImg.style.width = '100%'; mobImg.style.maxWidth = '240px'; mobImg.style.height = '115px'; }
                if (slot) slot.style.height = '105px';
                if (sizeTag) sizeTag.textContent = 'Selected: 1080 × 520 px (2:1)';
            } else if (ratio === '1080-600') {
                if (mobImg) { mobImg.style.width = '100%'; mobImg.style.maxWidth = '240px'; mobImg.style.height = '130px'; }
                if (slot) slot.style.height = '120px';
                if (sizeTag) sizeTag.textContent = 'Selected: 1080 × 600 px (16:9)';
            } else if (ratio === '4-5') {
                if (mobImg) { mobImg.style.width = '140px'; mobImg.style.height = '175px'; }
                if (slot) slot.style.height = '220px';
                if (sizeTag) sizeTag.textContent = 'Selected: 1080 × 1350 px (4:5)';
            } else if (ratio === '1-1') {
                if (mobImg) { mobImg.style.width = '140px'; mobImg.style.height = '140px'; }
                if (slot) slot.style.height = '190px';
                if (sizeTag) sizeTag.textContent = 'Selected: 1080 × 1080 px (1:1)';
            } else if (ratio === '9-16') {
                if (mobImg) { mobImg.style.width = '110px'; mobImg.style.height = '195px'; }
                if (slot) slot.style.height = '310px';
                if (sizeTag) sizeTag.textContent = 'Selected: 1080 × 1920 px (9:16)';
            } else if (ratio === '2-1') {
                if (mobImg) { mobImg.style.width = '200px'; mobImg.style.height = '85px'; }
                if (slot) slot.style.height = '85px';
                if (sizeTag) sizeTag.textContent = 'Selected: 750 × 320 px (2.3:1)';
            }
            this.showToast(`Mobile banner size set to ${ratio.replace('-', ' × ')} px!`);
        }
    },

    // ════ AI Banner Copy Auto-Generator ════
    generateAiBannerCopy: function() {
        const titleInput = document.getElementById('bannerTitle');
        const subInput = document.getElementById('bannerSubtitle');
        const ctaInput = document.getElementById('bannerCta');

        const headlines = [
            {
                title: "Surat Central Depot Mega Festival 2026",
                sub: "Authentic Pure Silk & Handloom Sarees • Direct Weaver Wholesale Pricing",
                cta: "Explore Wholesale Catalogues"
            },
            {
                title: "Royal Bridal & Velvet Heritage Edit",
                sub: "Heavy Hand Embroidered Zardosi Lehengas for Boutique Collections",
                cta: "View Bridal Assortment"
            },
            {
                title: "Reseller Low MOQ Deals (MOQ 4)",
                sub: "High Profit Resale Bundles • 24-Hour Express Depot Dispatch Across India",
                cta: "Order Wholesale Lots"
            }
        ];

        const chosen = headlines[Math.floor(Math.random() * headlines.length)];
        if (titleInput) titleInput.value = chosen.title;
        if (subInput) subInput.value = chosen.sub;
        if (ctaInput) ctaInput.value = chosen.cta;

        this.showToast(`AI Generated Banner Headlines & CTA!`);
    }
};

// ════ Master Display Settings Controller (2-Level User-Wise & Placement Engine) ════
window.DT_DISPLAY = {
    currentDevice: 'desk',
    currentUserType: 'customer',
    currentPlacement: 'shop',

    userNames: {
        'customer': 'Retail Customer (B2C)',
        'reseller': 'WhatsApp Reseller',
        'retailer': 'Retailer / Boutique',
        'wholesaler': 'Wholesale B2B'
    },

    placementNames: {
        'shop': 'Shop Grid',
        'collection': 'Collection Page',
        'single': 'Single Product Related',
        'home-trending': 'Home: Trending',
        'home-new': 'Home: New Arrivals',
        'home-sale': 'Home: Festive Sale',
        'home-recent': 'Home: Recently Viewed',
        'home-rec': 'Home: Recommended For You'
    },

    setUserType: function(type) {
        this.currentUserType = type;
        document.querySelectorAll('.dt-user-card-item, .dt-user-tab-btn').forEach(btn => btn.classList.remove('active'));
        const activeBtn = document.getElementById('user-' + type);
        if (activeBtn) activeBtn.classList.add('active');

        document.querySelectorAll('.user-active-tag').forEach(tag => tag.style.display = 'none');
        const activeTag = document.getElementById('tag-' + type);
        if (activeTag) activeTag.style.display = 'inline-block';

        // Audience Specific Intelligent Presets
        if (type === 'wholesaler') {
            document.getElementById('dspDeskCols').value = '4';
            document.getElementById('dspBtnStyle').value = 'gold';
            document.getElementById('chkB2bRate').checked = true;
            document.getElementById('chkMoq').checked = true;
            document.getElementById('chkDepotStock').checked = true;
        } else if (type === 'reseller') {
            document.getElementById('dspBtnStyle').value = 'emerald';
            document.getElementById('chkMargin').checked = true;
            document.getElementById('chkB2bRate').checked = true;
        } else if (type === 'retailer') {
            document.getElementById('dspDeskCols').value = '3';
            document.getElementById('dspBtnStyle').value = 'pale-gold';
            document.getElementById('dspCardRadius').value = '12px';
        } else {
            document.getElementById('dspDeskCols').value = '4';
            document.getElementById('dspBtnStyle').value = 'emerald';
        }

        this.renderContextCards();
        if (window.DT_CATALOGUE) {
            window.DT_CATALOGUE.showToast(`Switched Audience to ${this.userNames[type]}!`);
        }
    },

    setPlacement: function(place) {
        this.currentPlacement = place;
        document.querySelectorAll('.dt-subnav-pill').forEach(pill => pill.classList.remove('active'));
        const activePill = document.getElementById('sub-' + place);
        if (activePill) activePill.classList.add('active');

        this.renderContextCards();
        if (window.DT_CATALOGUE) {
            window.DT_CATALOGUE.showToast(`Placement: ${this.placementNames[place]}!`);
        }
    },

    renderContextCards: function() {
        const grid = document.getElementById('simulatedGrid');
        if (!grid) return;

        const badgeEl = document.getElementById('liveContextBadge');
        if (badgeEl) {
            badgeEl.innerHTML = `${this.userNames[this.currentUserType]} <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="display:inline-block; vertical-align:middle; margin:0 4px;"><polyline points="9 18 15 12 9 6"></polyline></svg> ${this.placementNames[this.currentPlacement]}`;
        }

        const cards = grid.querySelectorAll('.dt-sim-card');
        cards.forEach(card => {
            const pillBox = card.querySelector('.sim-context-pill');
            const btnText = card.querySelector('.sim-btn-text');
            const priceVal = card.getAttribute('data-price') || '2,850';
            const numPrice = parseInt(priceVal);

            if (pillBox) pillBox.style.display = 'block';

            // User-Wise & Placement Content
            if (this.currentUserType === 'wholesaler') {
                if (pillBox) {
                    pillBox.style.background = '#FAF5E8';
                    pillBox.style.border = '1px solid #D4AF37';
                    pillBox.style.color = '#181512';
                    pillBox.style.padding = '4px 6px';
                    pillBox.style.borderRadius = '4px';
                    pillBox.innerHTML = `<div>1–3 Pcs: <strong>₹${numPrice.toLocaleString()}</strong> • 4+ Pcs: <strong style="color:#15803D;">₹${Math.round(numPrice*0.9).toLocaleString()}</strong> • 12+ Lot: <strong style="color:#8A681F;">₹${Math.round(numPrice*0.84).toLocaleString()}</strong></div>`;
                }
                if (btnText) btnText.textContent = '+ Order Wholesale Master Lot';
            } else if (this.currentUserType === 'reseller') {
                if (pillBox) {
                    pillBox.style.background = '#EFF6FF';
                    pillBox.style.border = '1px solid #93C5FD';
                    pillBox.style.color = '#1D4ED8';
                    pillBox.style.padding = '4px 6px';
                    pillBox.style.borderRadius = '4px';
                    pillBox.innerHTML = `<div>Wholesale ₹${numPrice.toLocaleString()} • Resale Profit: <strong style="color:#15803D;">+₹${Math.round(numPrice*0.6).toLocaleString()} / Pc</strong></div>`;
                }
                if (btnText) btnText.textContent = 'Share on WhatsApp with My Margin';
            } else if (this.currentUserType === 'retailer') {
                if (pillBox) {
                    pillBox.style.background = '#FDFBF7';
                    pillBox.style.border = '1px solid #D4AF37';
                    pillBox.style.color = '#8A681F';
                    pillBox.style.padding = '4px 6px';
                    pillBox.style.borderRadius = '4px';
                    pillBox.innerHTML = `<div>Surat Central Depot Ready • Boutique Pack • GST Input</div>`;
                }
                if (btnText) btnText.textContent = 'Add Boutique Pack to PO';
            } else {
                // Customer Placement Specific Content
                if (this.currentPlacement === 'home-trending') {
                    if (pillBox) {
                        pillBox.style.background = '#FEF3C7';
                        pillBox.style.border = '1px solid #F59E0B';
                        pillBox.style.color = '#92400E';
                        pillBox.style.padding = '3px 6px';
                        pillBox.style.borderRadius = '4px';
                        pillBox.innerHTML = `Trending #1 in Surat Silk Hub`;
                    }
                    if (btnText) btnText.innerHTML = 'Explore Trending Collection <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="display:inline-block; vertical-align:middle; margin-left:4px;"><polyline points="9 18 15 12 9 6"></polyline></svg>';
                } else if (this.currentPlacement === 'home-new') {
                    if (pillBox) {
                        pillBox.style.background = '#FAF5E8';
                        pillBox.style.border = '1px solid #D4AF37';
                        pillBox.style.color = '#8A681F';
                        pillBox.style.padding = '3px 6px';
                        pillBox.style.borderRadius = '4px';
                        pillBox.innerHTML = `Fresh Weaver Stock 2026`;
                    }
                    if (btnText) btnText.innerHTML = 'View New Arrival Details <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="display:inline-block; vertical-align:middle; margin-left:4px;"><polyline points="9 18 15 12 9 6"></polyline></svg>';
                } else if (this.currentPlacement === 'home-sale') {
                    if (pillBox) {
                        pillBox.style.background = '#DCFCE7';
                        pillBox.style.border = '1px solid #16A34A';
                        pillBox.style.color = '#166534';
                        pillBox.style.padding = '3px 6px';
                        pillBox.style.borderRadius = '4px';
                        pillBox.innerHTML = `Festive Special Deal (Save 43%)`;
                    }
                    if (btnText) btnText.textContent = 'Claim Festive Discount Now';
                } else if (this.currentPlacement === 'home-recent') {
                    if (pillBox) {
                        pillBox.style.background = '#F1F5F9';
                        pillBox.style.border = '1px solid #CBD5E1';
                        pillBox.style.color = '#475569';
                        pillBox.style.padding = '3px 6px';
                        pillBox.style.borderRadius = '4px';
                        pillBox.innerHTML = `Viewed Today • In Stock (Surat Hub)`;
                    }
                    if (btnText) btnText.textContent = 'Instant 1-Tap Reorder';
                } else if (this.currentPlacement === 'home-rec') {
                    if (pillBox) {
                        pillBox.style.background = '#FAF5E8';
                        pillBox.style.border = '1px solid #D4AF37';
                        pillBox.style.color = '#8A681F';
                        pillBox.style.padding = '3px 6px';
                        pillBox.style.borderRadius = '4px';
                        pillBox.innerHTML = `98% AI Match for Your Boutique`;
                    }
                    if (btnText) btnText.textContent = 'Order Recommended Piece';
                } else if (this.currentPlacement === 'single') {
                    if (pillBox) {
                        pillBox.style.background = '#EFF6FF';
                        pillBox.style.border = '1px solid #93C5FD';
                        pillBox.style.color = '#1D4ED8';
                        pillBox.style.padding = '3px 6px';
                        pillBox.style.borderRadius = '4px';
                        pillBox.innerHTML = `Frequently Bundled with Blouse Piece`;
                    }
                    if (btnText) btnText.textContent = '+ Add Matching Saree Bundle';
                } else {
                    if (pillBox) pillBox.style.display = 'none';
                    if (btnText) btnText.textContent = 'WhatsApp Wholesale Lot';
                }
            }
        });

        this.updatePreview();
    },

    switchDevice: function(device) {
        this.currentDevice = device;
        const btnDesk = document.getElementById('btnDspDesk');
        const btnMob = document.getElementById('btnDspMob');
        const grid = document.getElementById('simulatedGrid');

        if (device === 'mob') {
            if (btnDesk) btnDesk.classList.remove('active');
            if (btnMob) btnMob.classList.add('active');
            if (grid) {
                grid.style.maxWidth = '380px';
                grid.style.margin = '0 auto';
            }
        } else {
            if (btnMob) btnMob.classList.remove('active');
            if (btnDesk) btnDesk.classList.add('active');
            if (grid) {
                grid.style.maxWidth = '100%';
                grid.style.margin = '0';
            }
        }
        this.updateCustomerStyles();
        if (window.DT_CATALOGUE) {
            window.DT_CATALOGUE.showToast(`Switched Live Simulator to ${device === 'mob' ? 'Mobile App' : 'Desktop Grid'} Mode!`);
        }
    },

    updatePreview: function() {
        this.updateCustomerStyles();
    },

    updateCustomerStyles: function() {
        const grid = document.getElementById('simulatedGrid');
        if (!grid) return;

        const tagStyle = document.getElementById('dspTagStyle')?.value || 'uppercase-gold';
        const nameStyle = document.getElementById('dspNameStyle')?.value || 'bold-1line';
        const priceStyle = document.getElementById('dspPriceStyle')?.value || 'emerald-price';
        const iconStyle = document.getElementById('dspIconStyle')?.value || 'glassmorphic';
        const btnStyleOpt = document.getElementById('dspBtnStyleOption')?.value || 'emerald-whatsapp';
        const btnSizeOpt = document.getElementById('dspBtnSizeOption')?.value || '28px';
        const radiusOpt = document.getElementById('dspCardRadiusOption')?.value || '8px';
        const gridColsOpt = document.getElementById('dspGridColsOption')?.value || '4-2';

        // 1. Responsive Columns
        const [dCols, mCols] = gridColsOpt.split('-');
        if (this.currentDevice === 'desk') {
            grid.style.gridTemplateColumns = `repeat(${dCols}, 1fr)`;
        } else {
            grid.style.gridTemplateColumns = `repeat(${mCols}, 1fr)`;
        }

        // 2. Visibility Checkboxes
        const chkSilkMark = document.getElementById('chkSilkMark')?.checked ?? true;
        const chkDepot = document.getElementById('chkDepotStock')?.checked ?? true;
        const chkUrgency = document.getElementById('chkUrgency')?.checked ?? true;
        const chkNewBadge = document.getElementById('chkNewBadge')?.checked ?? true;
        const chkBridalBadge = document.getElementById('chkBridalBadge')?.checked ?? true;
        const chkCatTag = document.getElementById('chkCatTag')?.checked ?? true;
        const chkWishlist = document.getElementById('chkWishlist')?.checked ?? true;
        const chkPhotoShare = document.getElementById('chkPhotoShare')?.checked ?? true;
        const chkRating = document.getElementById('chkRating')?.checked ?? true;
        const chkColorsSizes = document.getElementById('chkColorsSizes')?.checked ?? true;

        const cards = grid.querySelectorAll('.dt-sim-card');
        cards.forEach(card => {
            // Card Corner Radius & Theme
            card.style.borderRadius = radiusOpt;
            card.style.border = '1px solid #D4AF37';
            card.style.boxShadow = '0 4px 14px rgba(212,175,55,0.12)';
            
            const imgWrap = card.querySelector('.card-image-wrap');
            if (imgWrap) imgWrap.style.borderRadius = `${radiusOpt} ${radiusOpt} 0 0`;

            // 1. Tag Style
            const fabricTag = card.querySelector('.sim-fabric-tag');
            if (fabricTag) {
                if (tagStyle === 'uppercase-gold') {
                    fabricTag.style.color = '#8A681F';
                    fabricTag.style.textTransform = 'uppercase';
                } else if (tagStyle === 'uppercase-obsidian') {
                    fabricTag.style.color = '#181512';
                    fabricTag.style.textTransform = 'uppercase';
                } else if (tagStyle === 'uppercase-emerald') {
                    fabricTag.style.color = '#15803D';
                    fabricTag.style.textTransform = 'uppercase';
                } else {
                    fabricTag.style.color = '#64748b';
                    fabricTag.style.textTransform = 'capitalize';
                }
            }

            // 2. Name Typography
            const nameEl = card.querySelector('.sim-product-name');
            if (nameEl) {
                if (nameStyle === 'bold-2line') {
                    nameEl.style.fontSize = '0.82rem';
                    nameEl.style.fontWeight = '700';
                    nameEl.style.whiteSpace = 'normal';
                    nameEl.style.display = '-webkit-box';
                    nameEl.style.webkitLineClamp = '2';
                    nameEl.style.webkitBoxOrient = 'vertical';
                } else if (nameStyle === 'extrabold-1line') {
                    nameEl.style.fontSize = '0.90rem';
                    nameEl.style.fontWeight = '800';
                    nameEl.style.whiteSpace = 'nowrap';
                    nameEl.style.display = 'block';
                } else if (nameStyle === 'compact-1line') {
                    nameEl.style.fontSize = '0.76rem';
                    nameEl.style.fontWeight = '700';
                    nameEl.style.whiteSpace = 'nowrap';
                    nameEl.style.display = 'block';
                } else {
                    nameEl.style.fontSize = '0.82rem';
                    nameEl.style.fontWeight = '700';
                    nameEl.style.whiteSpace = 'nowrap';
                    nameEl.style.display = 'block';
                }
            }

            // 3. Price & Sale Pill Style
            const priceVal = card.querySelector('.sim-price-value');
            const discountPill = card.querySelector('.sim-discount-pill');
            if (priceVal) {
                if (priceStyle === 'emerald-price') {
                    priceVal.style.color = '#15803D';
                    priceVal.style.fontSize = '0.95rem';
                } else if (priceStyle === 'obsidian-price') {
                    priceVal.style.color = '#181512';
                    priceVal.style.fontSize = '0.95rem';
                } else if (priceStyle === 'gold-price') {
                    priceVal.style.color = '#8A681F';
                    priceVal.style.fontSize = '0.95rem';
                } else if (priceStyle === 'large-emerald') {
                    priceVal.style.color = '#15803D';
                    priceVal.style.fontSize = '1.10rem';
                }
            }
            if (discountPill) {
                if (priceStyle === 'large-emerald') {
                    discountPill.style.background = '#FEE2E2';
                    discountPill.style.color = '#DC2626';
                } else if (priceStyle === 'gold-price') {
                    discountPill.style.background = '#FAF5E8';
                    discountPill.style.color = '#8A681F';
                } else {
                    discountPill.style.background = '#DCFCE7';
                    discountPill.style.color = '#15803D';
                }
            }

            // 4. Icon Styles & Visibility
            const wishBtn = card.querySelector('.sim-wishlist-btn');
            const shareBtn = card.querySelector('.sim-share-btn');
            const ratingRow = card.querySelector('.sim-rating');
            const catTagEl = card.querySelector('.sim-cat-tag');
            const colorsRow = card.querySelector('.sim-colors-sizes');

            if (wishBtn) {
                wishBtn.style.display = (chkWishlist && iconStyle !== 'stars-only' && iconStyle !== 'minimal-clean') ? 'flex' : 'none';
            }
            if (shareBtn) {
                shareBtn.style.display = (chkPhotoShare && iconStyle !== 'wishlist-only' && iconStyle !== 'stars-only' && iconStyle !== 'minimal-clean') ? 'flex' : 'none';
            }
            if (ratingRow) {
                ratingRow.style.display = (chkRating && iconStyle !== 'minimal-clean') ? 'flex' : 'none';
            }
            if (catTagEl) {
                catTagEl.style.display = chkCatTag ? 'block' : 'none';
            }
            if (colorsRow) {
                colorsRow.style.display = chkColorsSizes ? 'flex' : 'none';
            }

            // Badges
            card.querySelectorAll('.card-badge.badge-heritage').forEach(el => el.style.display = chkSilkMark ? 'inline-block' : 'none');
            card.querySelectorAll('.card-badge.badge-trending').forEach(el => el.style.display = chkUrgency ? 'inline-block' : 'none');
            card.querySelectorAll('.card-badge.badge-new').forEach(el => el.style.display = chkNewBadge ? 'inline-block' : 'none');
            card.querySelectorAll('.card-badge.badge-bridal').forEach(el => el.style.display = chkBridalBadge ? 'inline-block' : 'none');
            card.querySelectorAll('.card-badge.badge-bestseller').forEach(el => el.style.display = chkDepot ? 'inline-block' : 'none');

            // 5. Button Styles
            const actionBtn = card.querySelector('.sim-action-btn');
            const btnText = card.querySelector('.sim-btn-text');
            if (actionBtn) {
                actionBtn.style.height = btnSizeOpt;
                actionBtn.style.borderRadius = (radiusOpt === '0px') ? '0px' : (btnSizeOpt === '34px' ? '8px' : '6px');
                
                actionBtn.classList.remove('emerald', 'gold', 'pale-gold');
                if (btnStyleOpt === 'emerald-whatsapp') {
                    actionBtn.classList.add('emerald');
                    if (btnText) btnText.textContent = 'WhatsApp Wholesale Lot';
                } else if (btnStyleOpt === 'gold-master') {
                    actionBtn.classList.add('gold');
                    if (btnText) btnText.textContent = '1-Click WhatsApp Enquiry';
                } else if (btnStyleOpt === 'pale-gold-pill') {
                    actionBtn.classList.add('pale-gold');
                    if (btnText) btnText.textContent = '+ Add to Bag / Cart';
                } else if (btnStyleOpt === 'obsidian-btn') {
                    actionBtn.style.background = 'linear-gradient(135deg, #181512 0%, #2A241E 100%)';
                    actionBtn.style.color = '#D4AF37';
                    actionBtn.style.border = '1px solid #8A681F';
                    if (btnText) btnText.innerHTML = 'View Saree Details <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="display:inline-block; vertical-align:middle; margin-left:4px;"><polyline points="9 18 15 12 9 6"></polyline></svg>';
                }
            }
        });

        // Update Live Header Parameters
        const pills = document.getElementById('liveParamPills');
        if (pills) {
            pills.textContent = `${dCols} Cols Desk • ${mCols} Cols Mob • ${btnSizeOpt} Button • ${radiusOpt} Radius`;
        }

        // Pulse Green Sync Indicator
        const pulse = document.getElementById('liveSyncPulse');
        if (pulse) {
            pulse.style.transform = 'scale(1.4)';
            setTimeout(() => { pulse.style.transform = 'scale(1)'; }, 200);
        }
    },

    toggleSection: function(bodyId, headerEl) {
        const body = document.getElementById(bodyId);
        if (!body) return;

        const isCollapsed = body.classList.toggle('collapsed');
        if (headerEl) {
            headerEl.classList.toggle('active', !isCollapsed);
            const sign = headerEl.querySelector('.dt-collapse-sign');
            const text = headerEl.querySelector('.dt-collapse-text');
            if (sign) sign.textContent = isCollapsed ? '+' : '−';
            if (text) text.textContent = isCollapsed ? 'Expand' : 'Collapse';
        }
    },

    expandAll: function() {
        for (let i = 1; i <= 4; i++) {
            const body = document.getElementById('sec-body-' + i);
            if (body) body.classList.remove('collapsed');
        }
        document.querySelectorAll('.dt-accordion-header').forEach(header => {
            header.classList.add('active');
            const sign = header.querySelector('.dt-collapse-sign');
            const text = header.querySelector('.dt-collapse-text');
            if (sign) sign.textContent = '−';
            if (text) text.textContent = 'Collapse';
        });
        if (window.DT_CATALOGUE) window.DT_CATALOGUE.showToast('Expanded all Display Setting sections!');
    },

    collapseAll: function() {
        for (let i = 1; i <= 4; i++) {
            const body = document.getElementById('sec-body-' + i);
            if (body) body.classList.add('collapsed');
        }
        document.querySelectorAll('.dt-accordion-header').forEach(header => {
            header.classList.remove('active');
            const sign = header.querySelector('.dt-collapse-sign');
            const text = header.querySelector('.dt-collapse-text');
            if (sign) sign.textContent = '+';
            if (text) text.textContent = 'Expand';
        });
        if (window.DT_CATALOGUE) window.DT_CATALOGUE.showToast('Collapsed all Display Setting sections!');
    },

    toggleSubGroup: function(grpId, btn) {
        const grp = document.getElementById(grpId);
        if (!grp) return;
        if (grp.style.display === 'none') {
            grp.style.display = 'grid';
            if (btn) btn.textContent = '− Minimize';
        } else {
            grp.style.display = 'none';
            if (btn) btn.textContent = '+ Expand';
        }
    },

    filterCards: function(query) {
        const grid = document.getElementById('simulatedGrid');
        if (!grid) return;
        const q = (query || '').toLowerCase().trim();
        const cards = grid.querySelectorAll('.dt-sim-card');
        let matchCount = 0;

        cards.forEach(card => {
            const text = card.textContent.toLowerCase();
            const sku = (card.getAttribute('data-badge') || '').toLowerCase();
            if (!q || text.includes(q) || sku.includes(q)) {
                card.style.display = 'flex';
                matchCount++;
            } else {
                card.style.display = 'none';
            }
        });

        const pagInfo = document.getElementById('livePaginationInfo');
        if (pagInfo) {
            pagInfo.innerHTML = `Showing <strong>${matchCount}</strong> matched simulated products (Filter: "${query}")`;
        }
    },

    applyPreset: function(preset) {
        if (preset === 'b2b') {
            const chkRating = document.getElementById('chkRating'); if (chkRating) chkRating.checked = true;
            const chkB2b = document.getElementById('chkB2bRate'); if (chkB2b) chkB2b.checked = true;
            const chkMargin = document.getElementById('chkMargin'); if (chkMargin) chkMargin.checked = true;
            const chkWhatsApp = document.getElementById('chkWhatsApp'); if (chkWhatsApp) chkWhatsApp.checked = true;
            const chkSilkMark = document.getElementById('chkSilkMark'); if (chkSilkMark) chkSilkMark.checked = true;
            const chkDepot = document.getElementById('chkDepotStock'); if (chkDepot) chkDepot.checked = true;
            const chkMoq = document.getElementById('chkMoq'); if (chkMoq) chkMoq.checked = true;
            const chkUrgency = document.getElementById('chkUrgency'); if (chkUrgency) chkUrgency.checked = true;
            
            const dCols = document.getElementById('dspDeskCols'); if (dCols) dCols.value = '4';
            const mCols = document.getElementById('dspMobCols'); if (mCols) mCols.value = '2';
            const ratio = document.getElementById('dspRatio'); if (ratio) ratio.value = '3-4';
            const theme = document.getElementById('dspCardTheme'); if (theme) theme.value = 'gold-border';
            const bStyle = document.getElementById('dspBtnStyle'); if (bStyle) bStyle.value = 'emerald';
            const bSize = document.getElementById('dspBtnSize'); if (bSize) bSize.value = 'normal';
            const radius = document.getElementById('dspCardRadius'); if (radius) radius.value = '8px';
            
            this.updatePreview();
            this.switchPortal('shop');
            if (window.DT_CATALOGUE) window.DT_CATALOGUE.showToast('Applied Surat B2B Wholesale Preset!');
        } else if (preset === 'boutique') {
            const chkRating = document.getElementById('chkRating'); if (chkRating) chkRating.checked = true;
            const chkB2b = document.getElementById('chkB2bRate'); if (chkB2b) chkB2b.checked = false;
            const chkMargin = document.getElementById('chkMargin'); if (chkMargin) chkMargin.checked = false;
            const chkWhatsApp = document.getElementById('chkWhatsApp'); if (chkWhatsApp) chkWhatsApp.checked = true;
            const chkSilkMark = document.getElementById('chkSilkMark'); if (chkSilkMark) chkSilkMark.checked = true;
            const chkDepot = document.getElementById('chkDepotStock'); if (chkDepot) chkDepot.checked = false;
            const chkMoq = document.getElementById('chkMoq'); if (chkMoq) chkMoq.checked = false;
            const chkUrgency = document.getElementById('chkUrgency'); if (chkUrgency) chkUrgency.checked = true;
            
            const dCols = document.getElementById('dspDeskCols'); if (dCols) dCols.value = '3';
            const mCols = document.getElementById('dspMobCols'); if (mCols) mCols.value = '1';
            const ratio = document.getElementById('dspRatio'); if (ratio) ratio.value = '4-5';
            const theme = document.getElementById('dspCardTheme'); if (theme) theme.value = 'gold-border';
            const bStyle = document.getElementById('dspBtnStyle'); if (bStyle) bStyle.value = 'gold';
            const bSize = document.getElementById('dspBtnSize'); if (bSize) bSize.value = 'large';
            const radius = document.getElementById('dspCardRadius'); if (radius) radius.value = '12px';
            
            this.updatePreview();
            this.switchPortal('home');
            if (window.DT_CATALOGUE) window.DT_CATALOGUE.showToast('Applied Luxury Boutique Preset!');
        }
    }
};
