/** merchandising.js **/
